/* rsa.h for openSSL */


#ifndef CYASSL_RSA_H_
#define CYASSL_RSA_H_

enum { RSA_F4 = 1 };


#endif /* header */
